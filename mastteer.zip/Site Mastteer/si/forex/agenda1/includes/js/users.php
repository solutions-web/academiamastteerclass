<?php /* $Id: users.php,v 1.12.2.2 2007/08/06 02:28:27 cknudsen Exp $  */ 

 //see the showTab function in includes/js/visible.php for common code shared by all pages
  //using the tabbed GUI.
?>var tabs = new Array ();
tabs[1] = "users";
tabs[2] = "groups";
tabs[3] = "nonusers";
tabs[4] = "remotes";

