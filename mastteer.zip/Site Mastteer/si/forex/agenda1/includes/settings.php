<?php
/* updated via install/index.php on Mon, 14 Nov 2016 11:14:04 -0500
install_password: 8516b07e8c643fe9e79edee1464ea828
db_type: mysql
db_host: localhost
db_database: informat_master1
db_login: informat_maste1
db_password: Odisseia1
db_persistent: false
db_cachedir: /tmp
readonly: false
user_inc: user.php
use_http_auth: false
single_user: true
single_user_login: admin
# end settings.php */
?>
